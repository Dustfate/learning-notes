#### 内容介绍

#### 1、nginx基本概念

##### 1.1 什么是nginx

nginx是一个高性能的HTTP和反向代理的web服务器，同时也提供了IMAP/POP3/SMTP服务。
特点：占用内存少，并发能力强

##### 1.2 什么是反向代理

###### （1）正向代理

​        用户知道目标服务器地址，但由于网络限制等原因，无法直接访问。这时候需要先连接代理服务器，然后再由代理服务器访问目标服务器。

![](Nginx.assets/image-20201025133648617.png)

###### （2）反向代理

​		反向代理对用户则是不可知的，客户端不需要任何配置就可以访问，只需要将请求发送到反向代理服务器，由反向代理服务器去选择目标服务器，然后获取数据后返回给客户端。比如我们访问百度网站，百度的代理服务器对外的域名为 www.baidu.com。具体内部的服务器节点我们不知道，现实中我们通过访问百度的代理服务器后，代理服务器给我们转发请求到他们N多的服务器节点中的一个给我们进行搜索后将结果返回。

![](Nginx.assets/image-20201025135002017.png)

##### 1.3 什么是负载均衡

​		客户端发送多个请求到服务器，服务器处理请求。有一些可能要与数据库进行交互，服务器处理完毕后，再将结果返回给客户端。

![](Nginx.assets/image-20201025141100758.png)

​		这种架构模式对于早期相对单一的系统，并发请求相对较少的情况下是比较合适的，成本也低。但是随着信息数量的不断增长，访问量和数据量的飞速增长，以及数据业务的复杂度增加，这种架构会造成服务器响应客户端的请求日益缓慢，并发量特别大的时候，还容易导致服务器崩溃。
​		很明显这是服务器性能的瓶颈造成的问题，那么如何解决这种情况呢？
​		我们首先想到的是升级服务器的配置，比如提高CPU、加大内存等提高机器的物理性能来解决问题。但是我们知道摩尔定律日益失效，硬件的提升已经不能满足需求了。例如天猫双十一当天，某个热销商品的瞬时访问量是极其庞大的，那么类似上面的架构，将机器都增加到现有的顶级物理配置，都不能满足需求，那该怎么办？

​		上面的分析表明通过增加服务器物理配置来解决问题的方法，即纵向解决问题的方法已经行不通了。那么横向增加服务器的数量呢？集群的概念就这样产生了。

![](Nginx.assets/image-20201025142405623.png)

​		单台服务器解决不了，我们增加服务器的数量，然后将请求分发到各个服务器上，将原来请求集中到单个服务器上的情况，改为将请求分发到多个服务器上，将负载分发到不同的服务器上，也就是我们所说的负载均衡。

##### 1.4 什么是动静分离

​		把静态资源和动态资源都部署到同一台服务器中，每次请求不管是静态资源，还是动态资源，都去请求该服务器。用单个服务部署所有的内容。
​		局限性：请求静态资源和动态资源都去请求同一台服务器，会带来更大的压力。

![](Nginx.assets/image-20201025142946348.png)

​		为了加快网站的解析速度，可以把动态页面和静态页面由不同的服务器来解析，加快解析速度，降低原来单个服务器的压力。

![](Nginx.assets/image-20201025143223363.png)

#### 2、nginx安装、常用命令和配置文件

##### 2.1 在Linux系统中安装nginx

Nginx官网提供了三个类型的版本
Mainline version：Mainline 是 Nginx 目前主力在做的版本，可以说是开发版
Stable version：最新稳定版，生产环境上建议使用的版本
Legacy versions：遗留的老版本的稳定版

地址：http://nginx.org/en/download.html

```shell
# 在安装nginx前首先要确认系统中安装了make、gcc、pcre-devel、zlib-devel、openssl-devel。
yum -y install make gcc pcre-devel zlib-devel openssl openssl-devel

# 解压文件
tar -zxvf nginx-1.18.0.tar.gz

# 进入nginx目录
cd nginx-1.18.0

## 配置
./configure --prefix=/usr/local/nginx

# make
make && make install

# 测试是否安装成功
# cd到刚才配置的安装目录/usr/loca/nginx/
./sbin/nginx -t
# 正常情况的信息输出：
# nginx: the configuration file /usr/local/nginx/conf/nginx.conf syntax is ok
# nginx: configuration file /usr/local/nginx/conf/nginx.conf test is successful
```

在浏览器访问服务器地址，如下图：

![](Nginx.assets/image-20201025150357787.png)

```shell
# 默认80端口是不开放的,如果访问失败需要查看端口是否已开放
# 查看开放的端口号
firewall-cmd --list-all
# 或者
firewall-cmd --query-port=80/tcp

# 设置开放的端口号 permanent永久生效，没有此参数重启后失效
firewall-cmd --add-service=http -permanent
firewall-cmd --add-port=80/tcp --permanent
# 重启防火墙
systemctl restart firewalld
# 或者
firewall-cmd --reload

# 配置开机启动
vim /etc/rc.d/rc.local
# 添加下面的路径
/usr/local/nginx/sbin/nginx
```

##### 2.2 nginx常用命令

```shell
# 首先要进入/usr/local/nginx/sbin目录
# 查看版本号
./nginx -v
# 启动
./nginx
# 停止
./nginx -s stop
# 重新加载配置信息
./nginx -s reload
```

##### 2.3 nginx的配置文件

```shell
# 配置文件地址/usr/local/nginx/conf/nginx.conf
# 查看配置文件
vim nginx.conf
```

```shell
#user  nobody;#定义Nginx运行的用户和用户组

#工作进程：数目。根据硬件调整，通常等于cpu数量或者2倍cpu数量。
worker_processes  1;

#错误日志存放路径,日志定义类型[ debug | info | notice | warn | error | crit ]
#error_log  logs/error.log;
#error_log  logs/error.log  notice;
#error_log  logs/error.log  info;

# nginx进程pid存放路径
#pid        logs/nginx.pid;

events {
    worker_connections  1024;# 工作进程的最大连接数量
}

http {
	#指定mime类型，由mime.type来定义
    include       mime.types;
    default_type  application/octet-stream;

	#日志格式设置
    #log_format  main  '$remote_addr - $remote_user [$time_local] "$request" '
    #                  '$status $body_bytes_sent "$http_referer" '
    #                  '"$http_user_agent" "$http_x_forwarded_for"';

	#用log_format指令设置日志格式后，需要用access_log来指定日志文件存放路径
    #access_log  logs/access.log  main;

	#指定nginx是否调用sendfile函数来输出文件，对于普通应用，必须设置on。
	#如果用来进行下载等应用磁盘io重负载应用，可设着off，以平衡磁盘与网络io处理速度，降低系统uptime。
    sendfile        on;
    
    #此选项允许或禁止使用socket的TCP_CORK的选项，此选项仅在sendfile的时候使用
    #tcp_nopush     on;

	## (单位s)设置客户端连接保持活动的超时时间,在超过这个时间后服务器会关闭该链接
    #keepalive_timeout  0;
    keepalive_timeout  65;

	#开启gzip压缩服务
    #gzip  on;

	#虚拟主机
    server {
    	#配置监听端口号
        listen       80;
        #配置访问域名，域名可以有多个，用空格隔开
        server_name  localhost;

		#字符集设置
        #charset koi8-r;

        #access_log  logs/host.access.log  main;

        location / {
            root   html;
            index  index.html index.htm;
        }

		#错误跳转页
        #error_page  404              /404.html;

        # redirect server error pages to the static page /50x.html
        #
        error_page   500 502 503 504  /50x.html;
        location = /50x.html {
            root   html;
        }

        # proxy the PHP scripts to Apache listening on 127.0.0.1:80
        #
        #location ~ \.php$ {
        #    proxy_pass   http://127.0.0.1;
        #}

        # pass the PHP scripts to FastCGI server listening on 127.0.0.1:9000
        #
        #请求的url过滤，正则匹配，~为区分大小写，~*为不区分大小写。
        #location ~ \.php$ {
        #    root           html;#根目录
        #    fastcgi_pass   127.0.0.1:9000;#请求转向定义的服务器列表
        #    fastcgi_index  index.php;#如果请求的Fastcgi_index URI是以 / 结束的, 该指令设置的文件会被附加到URI的后面并保存在变量$fastcig_script_name中
        #    fastcgi_param  SCRIPT_FILENAME  /scripts$fastcgi_script_name;
        #    include        fastcgi_params;
        #}

        # deny access to .htaccess files, if Apache's document root
        # concurs with nginx's one
        #
        #location ~ /\.ht {
        #    deny  all;
        #}
    }

    # another virtual host using mix of IP-, name-, and port-based configuration
    #
    #server {
    #    listen       8000;
    #    listen       somename:8080;
    #    server_name  somename  alias  another.alias;

    #    location / {
    #        root   html;
    #        index  index.html index.htm;
    #    }
    #}

    # HTTPS server
    #
    #server {
    #    listen       443 ssl;#监听端口
    #    server_name  localhost;#域名

    #    ssl_certificate      cert.pem;#证书位置
    #    ssl_certificate_key  cert.key;#私钥位置

    #    ssl_session_cache    shared:SSL:1m;
    #    ssl_session_timeout  5m;

    #    ssl_ciphers  HIGH:!aNULL:!MD5;#密码加密方式
    #    ssl_prefer_server_ciphers  on;

    #    location / {
    #        root   html;
    #        index  index.html index.htm;
    #    }
    #}

}
```

参考地址：https://www.cnblogs.com/1993zzd/p/11987442.html

location指令说明：

语法如下：

```shell
localtion [ = | ~ | ~* | ^~] uri {
	
}
```

1、=：用于不含正则表达式的uri前，要求请求字符串与uri严格匹配，如果匹配成功，就停止继续向下搜索并立即处理该请求。

2、~：用于表示uri包含正则表达式，并且区分大小写。

3、~*：用于表示uri包含正则表达式，并且不区分大小写。

4、^~：用于不包含正则表达式的uri前，要求nginx服务器找到标识uri和请求字符串匹配度最高的location后，立即使用此location处理请求，而不再使用location块中的正则uri和请求字符串做匹配。



#### 3、nginx配置实例（反向代理）

```shell
server {
    #配置监听端口号
    listen       8088;
    #配置访问域名，域名可以有多个，用空格隔开
    server_name  172.16.193.95;

    #添加转发地址
    location / {
        proxy_pass http://www.baidu.com;
    }
    
    #添加转发地址
    location /wjtb {
        proxy_pass http://www.baidu.com;
    }
}
```



#### 4、nginx配置实例（负载均衡）

```shell
# 负载均衡配置
upstream myserver {
	server 172.16.193.174:8070;
	server 172.16.193.175:8080;
}

server {
    listen       8080;
    server_name  172.16.193.95;
	
    #添加转发地址
    location / {
        proxy_pass http://myserver;
        proxy_set_header X-Real-IP $remote_addr;#后端的Web服务器可以通过X-Real-IP（变量，可以自己定义）获取用户真实IP
    }
}
```

**upstream的负载均衡,四种调度算法**
**调度算法1：**轮询（默认）。每个请求按时间顺序逐一分配到不同的后端服务器，如果后端某台服务器宕机，那么故障系统被自动剔除，使用户访问不受影响。

```shell
upstream myserver {
	server 172.16.193.95:6666;
	server 172.16.193.96:6666;
}
```

**调度算法2：**weight(权重)。可以根据机器配置定义权重，权重越高被分配到的几率越大，用于服务器性能不均。

```shell
upstream myserver {
	server 172.16.193.95:6666 weight=2;
	server 172.16.193.96:6666 weight=3;
}
```

**调度算法3：**ip_hash。每个请求按访问IP的hash结果分配，这样来自同一个IP的访客固定访问一个后端服务器，有效解决了动态网页存在的session共享问题。

```sh
upstream myserver {
	ip_hash;
	server 172.16.193.95:6666 ;
	server 172.16.193.96:6666 ;
}
```

**调度算法4：**url_hash(需安装第三方插件)。此方法按访问url的hash结果来分配请求，使每个url定向到同一个后端服务器，可以进一步提高后端缓存服务器的效率。nginx本身是不支持url_hash的，如果需要使用这种调度算法，必须安装nginx的hash软件包

```shell
upstream myserver {
	server 172.16.193.95:6666 ;
	server 172.16.193.96:6666 ;
    hash $request_uri;
}
```

**调度算法5：**fair(需安装第三方插件)。这是比上面两个更加智能的负载均衡算法。此种算法可以依据页面大小和加载时间长短智能地进行负载均衡，也就是根据后端服务器的响应时间来分配请求，响应时间短的优先分配。nginx本身是不支持fair的，如果需要使用这种调度算法必须下载nginx的upstream_fair模块。

#### 5、nginx配置实例（动静分离）

​		nginx动静分离简单来说就是把动态跟静态请求分开，不能理解成只是单纯的把动态页面和静态页面物理分离。严格意义上说应该是动态请求跟静态请求分开，可以理解成使用nginx 处理静态页面，Tomcat处理动态页面。动静分离从目前实现角度来讲大致分为两种。		一种是纯粹把静态文件独立成单独的域名，放在独立的服务器上，也是目前主流推崇的方案。

​		另外一种方法就是动态跟静态文件混合在一起发布，通过nginx 来分开，通 过 location指定不同的后缀名实现不同的请求转发，通过 expires参数设置，可以使浏览器缓存过期时间，减少与服务器之前的请求和流量。具 体 expires定义：是给一个资源设定一个过期时间，也就是说无需去服务端验证，直接通过浏览器自身确认是否过期即可， 所以不会产生额外的流量。此种方法非常适合不经常变动的资源(如果经常更新的文件，不建议使用expires来缓存），我这里设置3d，表示在这3天之内访问这个URL，发送 一个请求，比对服务器该文件最后更新时间没有变化，则不会从服务器抓取，返回状态码 304，如果有修改，则直接从服务器重新下载，返回状态码200。

```shell
server {
    listen       80;
    server_name  172.16.193.95;
	
    #静态资源地址
    location /www/ {
    	root /data/;#静态资源路径
        index index.html index.htm;
    }
    
    #静态资源地址
    location /image/ {
    	root /data/;#静态资源路径
        autoindex on;#是否显示访问目录 on是打开 off关闭
    }
}
```

在浏览器中输入http://172.16.193.95/www/会显示/data/www目录下的所有内容。

在浏览器中输入http://172.16.193.95/image/会显示/data/image目录下的所有内容。

#### 6、nginx配置高可用集群

**高可用依赖keepalived。**Keepalived 是一种高性能的服务器高可用或热备解决方案，Keepalived 可以用来防止服务器单点故障的发生，通过配合 nginx 可以实现 web 前端服务的高可用。

![](Nginx.assets/image-20201025212022811.png)

keepalive相当于一个路由，对外会提供一个虚拟的IP，并且通过脚本检测当前nginx服务器状态，如果宕机则切换到另一台nginx服务器。

```shell
#安装keepalived
yum install keepalived -y

#配置文件地址
cd /etc/keepalived

#编辑配置文件
vim keepalived.conf
```

```shell
! Configuration File for keepalived
#全局定义块
global_defs {
    # 邮件通知配置,用于服务有故障时发送邮件报警，可选项，不建议用。
	notification_email {
		acassen@firewall.loc
		failover@firewall.loc
		sysadmin@firewall.loc
    }
    notification_email_from Alexandre.Cassen@firewall.loc
	smtp_server 192.168.200.1
	smtp_connect_timeout 30
	router_id LVS_DEVEL # 标识本节点的字条串,通常为hostname,可通过vim /etc/hosts查看或修改
   	vrrp_skip_check_adv_addr
   	vrrp_strict
   	vrrp_garp_interval 0
	vrrp_gna_interval 0
}

## keepalived会定时执行脚本并对脚本执行的结果进行分析,动态调整vrrp_instance的优先级。
##如果脚本执行结果为0，并且weight配置的值大于0，则优先级相应的增加。如果脚本执行结果非0，
##并且weight配置的值小于0，则优先级相应的减少。其他情况，维持原本配置的优先级，即配置文件中priority对应的值。
vrrp_script chk_nginx {
	script "/etc/keepalived/nginx_check.sh"
	interval 2  #每2秒检测一次nginx的运行状态
	weight -20  #失败一次，将自己的优先级-20
}

vrrp_instance VI_1 {
	#实例状态，只有MASTER和BACKUP两种状态，并且需要全部大写。抢占模式下，其中MASTER为工作状态，BACKUP为备用状态。当MASTER所在的服务器失效时，BACKUP所在的服务会自动把它的状态由BACKUP切换到MASTER状态。当失效的MASTER所在的服务恢复时，BACKUP从MASTER恢复到BACKUP状态。
    state MASTER
    interface eth0 #网卡,通过ifconfig查看自己的网络接口
    virtual_router_id 51 #主、备服务器的virtual_router_id必须相同
    mcast_src_ip 192.168.1.201 # 本机IP地址
    priority 100 #主、备服务器取不通的优先级，主的值较大，备的值较小
    advert_int 1 #MASTER与BACKUP节点间同步检查的时间间隔，单位为秒
    
    authentication {
    	#验证类型和验证密码。类型主要有 PASS、AH 两种，通常使用PASS类型，据说AH使用时有问题。验证密码为明文，同一vrrp实例MASTER与BACKUP使用相同的密码才能正常通信。
    	auth_type PASS
        auth_pass 1111
    }
    #虚拟IP地址池，可以有多个IP，每个IP占一行，不需要指定子网掩码。注意：这个IP必须与我们的设定的vip保持一致。
    virtual_ipaddress {
        192.168.200.16 #VRRP H虚拟地址
        192.168.200.17
        192.168.200.18
    }
    
    track_script {
       chk_nginx  # nginx存活状态检测脚本
    }
}
#虚拟服务器定义块
#定义一个虚拟服务器，这个ip是virtual_ipaddress中定义的其中一个，后面一个空格，然后加上虚拟服务的端口号。
virtual_server 192.168.200.100 443 {
    delay_loop 6 #健康检查时间间隔，单位：秒
    lb_algo rr #负载均衡调度算法，互联网应用常用方式为wlc或rr
    lb_kind NAT #负载均衡转发规则。包括DR、NAT、TUN 3种，一般使用路由（DR）转发规则。
    persistence_timeout 50 #http服务会话保持时间，单位：秒
    protocol TCP #转发协议，分为TCP和UDP两种
	
	#真实服务器IP和端口，可以定义多个
    real_server 192.168.201.100 443 {
        weight 1 #
        SSL_GET {
            url {
              path /
              digest ff20ad2481f97b1754ef3e12ecd3a9cc
            }
            url {
              path /mrtg/
              digest 9b3a0c85a887a256d6939da88aabd8cd
            }
            connect_timeout 3
            nb_get_retry 3
            delay_before_retry 3
        }
    }
}
```

分别在主备服务器`/etc/keepalived`目录下创建`nginx_check.sh`脚本。用于keepalived定时检测nginx的服务状态，如果nginx停止了，会尝试重新启动nginx，如果启动失败，会将keepalived进程杀死，将vip漂移到备份机器上。

```shell
#!/bin/bash
A=`ps -C nginx --no-header | wc -l`
if [ $A -eq 0 ];then
    /usr/local/nginx/sbin/nginx #nginx启动地址，尝试重新启动nginx
    sleep 2  #睡眠2秒
    if [ `ps -C nginx --no-header | wc -l` -eq 0 ];then
        killall keepalived #启动失败，将keepalived服务杀死。将vip漂移到其它备份节点
    fi
fi
```

启动keepalived服务

```shell
service keepalived start
```

注：

抢占模式和非抢占模式的配置相比，非抢占模式只改了两个地方：
1、在vrrp_instance块下两个节点各增加nopreempt指令，表示不争抢vip
2、节点的state都为BACKUP
两个keepalived节点都启动后，默认都是BACKUP状态，双方在发送组播信息后，会根据优先级来选举一个MASTER出来。由于两者都配置了nopreempt，所以MASTER从故障中恢复后，不会抢占vip。这样会避免VIP切换可能造成的服务延迟。



#### 7、nginx原理

###### 7.1 模块化设计

高度模块化的设计是nginx的架构基础。在nginx中，除了少量的核心代码，其他一切皆为模块。所有模块间是分层次、分类别的，nginx官方共有五大类型的模块：核心模块、配置模块、事件模块、HTTP模块、mail模块。

![](Nginx.assets/image-20201025225827602.png)

###### 7.2 master和worker

![](Nginx.assets/image-40244f461.jpg)

**一个master进程，可生成一个或多个worker进程**

​	master：负责加载分析配置文件、管理worker进程、平滑升级、...

​	worker：处理并响应用户请求

​	nginx启动后会有一个master进程和多个worker进程。master进程主要用来管理worker进程，包括介绍来自外界的信号，向各个worker进程发送信号，监控worker进程的运行状态以及启动worker进程。worker进程是用来处理来自客户端的请求事件的。多个worker进程之间是对等的，他们同等竞争来自客户端的请求，进程间相互独立，一个请求只能在一个worker进程中处理。

​	worker进程的个数是可以设置的，一般会设置与机器的cpu核数一致。每个worker有核心模块core和外围的诸多模块modules组成，为了实现http功能有http协议的ht_core模块，为了功能完善还有很多其它模块。如实现负载均衡的ht_upstream模块，ht_proxy反代模块，fastcgi模块ht_fastcgi模块。用到哪些功能编译哪些模块或载入哪些模块即可；基于每种模块，可以与后端的不同应用通信；例如基于ht_core模块可与web server通信，基于ht_fastcgi模块可与php通信；基于memcache模块可与mamcache通信等。